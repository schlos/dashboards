define(function() {
	return (/^margin/);
});
